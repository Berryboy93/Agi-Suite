import express from "express";

const app = express();
app.use(express.json());

// HEALTH CHECK (UI depends on this)
app.get("/health", (req, res) => {
  res.json({ ok: true, service: "api-server" });
});

// ROOT (prevents 404 confusion)
app.get("/", (req, res) => {
  res.json({ status: "online", name: "r3-api" });
});

// API namespace (IMPORTANT for UI stability)
app.get("/api/status", (req, res) => {
  res.json({ status: "ok", timestamp: Date.now() });
});

app.listen(3001, () => {
  console.log("API running on http://localhost:3001");
});