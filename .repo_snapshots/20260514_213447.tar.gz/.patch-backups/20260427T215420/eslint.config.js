// eslint.config.js — FR-018
// Flat config (ESLint 9+). Plugins: @typescript-eslint, react-hooks, prettier.
// Rule: zero lint errors on current codebase before enabling new rules.

import tsPlugin from "@typescript-eslint/eslint-plugin";
import tsParser from "@typescript-eslint/parser";
import reactHooks from "eslint-plugin-react-hooks";
import prettierConfig from "eslint-config-prettier";

export default [
  // ── Global ignores ────────────────────────────────────────────────────────
  {
    ignores: [
      "**/dist/**",
      "**/node_modules/**",
      "**/.patch-backups/**",
      "pnpm-lock.yaml",
      "**/*.bak",
      "**/*.bak-*",
    ],
  },

  // ── TypeScript source files ───────────────────────────────────────────────
  {
    files: ["**/*.ts", "**/*.tsx"],
    languageOptions: {
      parser: tsParser,
      parserOptions: {
        project: "./tsconfig.json",
        tsconfigRootDir: import.meta.dirname,
      },
    },
    plugins: {
      "@typescript-eslint": tsPlugin,
    },
    rules: {
      // Recommended rules — type-checked variants where available
      ...tsPlugin.configs["recommended"].rules,

      // Project-specific overrides
      "@typescript-eslint/no-explicit-any": "error", // PRD: no `any`
      "@typescript-eslint/no-floating-promises": "error", // catch unhandled async
      "@typescript-eslint/no-unused-vars": [
        "error",
        { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
      ],
      "@typescript-eslint/consistent-type-imports": "warn",
    },
  },

  // ── React / frontend files ────────────────────────────────────────────────
  {
    files: ["apps/r3-agi/src/**/*.ts", "apps/r3-agi/src/**/*.tsx"],
    plugins: {
      "react-hooks": reactHooks,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
    },
  },

  // ── Prettier compat — must be last (disables formatting rules) ────────────
  prettierConfig,
];
