/**
 * FR-021 — Metrics PostgreSQL Persistence
 *
 * Thin wrapper around the metrics_kv table. Used by routes/metrics.ts to
 * persist totalSubscribers so a Railway redeploy does not reset the count.
 *
 * All operations are async fire-and-forget — callers should never await these
 * unless they explicitly need the confirmed write. DB failures are logged but
 * never surfaced to the client (heartbeat must always respond quickly).
 *
 * The metrics_kv schema (defined in PRD v2.0 / lib/db):
 *   key   varchar(64)  PRIMARY KEY
 *   value text         NOT NULL
 */

import { db } from "./db.js"; // adjust to your actual Drizzle db export path
import { metricsKv } from "@workspace/db/schema"; // adjust to your schema export

/** Read a single metric value by key. Returns null if not found. */
export async function readMetric(key: string): Promise<string | null> {
  try {
    const row = await db.query.metricsKv.findFirst({
      where: (t, { eq }) => eq(t.key, key),
    });
    return row?.value ?? null;
  } catch {
    return null;
  }
}

/**
 * Upsert a metric value. Non-blocking — call without await.
 * DB failure is silently swallowed (metrics writes must not block responses).
 */
export function writeMetric(key: string, value: string): void {
  db.insert(metricsKv)
    .values({ key, value })
    .onConflictDoUpdate({
      target: metricsKv.key,
      set: { value },
    })
    .catch((err: unknown) => {
      // Non-fatal: metrics writes are best-effort
      console.warn("[db-metrics] write failed:", (err as Error)?.message);
    });
}
