#!/usr/bin/env bash
set -euo pipefail

echo "🧠 Dependency health check..."

cd ~/Agi-Suite

# API critical deps
if ! grep -q "express" apps/api-server/package.json; then
  echo "⚠️ Fixing missing API deps..."
  pnpm add express cors helmet morgan dotenv zod --filter @workspace/api-server
fi

echo "✅ Dependencies OK"
