#!/usr/bin/env bash

set -euo pipefail

echo "🔥 R3 SYSTEM BOOT SEQUENCE"

~/Agi-Suite/tools/dev/port-kill.sh
~/Agi-Suite/tools/dev/r3-doctor.sh
~/Agi-Suite/tools/dev/r3-dev.sh

echo "🚀 SYSTEM ONLINE"
